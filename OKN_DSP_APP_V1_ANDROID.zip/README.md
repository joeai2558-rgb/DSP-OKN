# OKN DSP App V1
Android starter project based on OKN_DSP_APP_RESEARCH_DATA_V1.
Current build: BLE scan/device discovery. No unverified DSP writes.
Next: add GATT discovery, notification capture, then evidence-driven protocol codec.
