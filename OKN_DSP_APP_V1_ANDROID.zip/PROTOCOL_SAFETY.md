# Protocol safety
This starter app implements BLE discovery only. It does NOT send guessed DSP command payloads.
Confirmed research:
- Custom service AB00
- AB01: READ/WRITE/WRITE_NR
- AB02: NOTIFY
- AB03: NOTIFY
- Device names must be discovered dynamically.
Future command codec must only be enabled after controlled-capture evidence confirms framing, opcode, checksum, parameter encoding and addressing.
