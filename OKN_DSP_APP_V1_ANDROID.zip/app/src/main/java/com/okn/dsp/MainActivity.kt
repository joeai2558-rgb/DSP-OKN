package com.okn.dsp
import android.Manifest
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity: AppCompatActivity() {
 private val devices=linkedMapOf<String,BluetoothDevice>()
 private lateinit var adapter:ArrayAdapter<String>
 private lateinit var status:TextView
 private var scanner:BluetoothLeScanner?=null
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main)
  status=findViewById(R.id.status); adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,ArrayList()); findViewById<ListView>(R.id.devices).adapter=adapter
  findViewById<Button>(R.id.scan).setOnClickListener{startScan()}
  if(android.os.Build.VERSION.SDK_INT>=31) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT),10)
 }
 private fun startScan(){val bm=getSystemService(BLUETOOTH_SERVICE) as BluetoothManager; scanner=bm.adapter.bluetoothLeScanner; devices.clear();adapter.clear();status.text="กำลังสแกน..."
  scanner?.startScan(callback); window.decorView.postDelayed({scanner?.stopScan(callback);status.text="พบ ${devices.size} อุปกรณ์"},10000)}
 private val callback=object:ScanCallback(){override fun onScanResult(t:Int,r:ScanResult){val d=r.device; val n=d.name?:r.scanRecord?.deviceName?:"Unknown"; if(!devices.containsKey(d.address)){devices[d.address]=d;adapter.add("$n\n${d.address}")}}}
}