# OKN DSP App — Next Step: Protocol Capture

## เป้าหมาย
ทำให้มือถือเชื่อมต่อ DSP จริงและเก็บ packet ที่ DSP ส่งกลับ เพื่อใช้ยืนยัน protocol ก่อนเปิด WRITE

## สิ่งที่เพิ่มใน V3
1. BLE scan/connect
2. GATT service/characteristic discovery
3. Notification capture
4. Timestamp ของ packet
5. RX/READ hex log
6. Export log ผ่าน Share ของ Android
7. ยังไม่ส่ง WRITE command ไป DSP

## ขั้นตอนทดสอบจริง
มือถือ -> เปิด Bluetooth -> Build APK -> ติดตั้ง -> สแกน DSP -> Connect -> รอ packet

จากนั้นต้องทดสอบกับแอปเดิมที่ใช้งาน DSP ได้จริง แล้วเปลี่ยนค่าทีละอย่าง เช่น Volume หรือ EQ เพื่อให้ได้ TX packet ที่ตรงกับการเปลี่ยนค่า

## Gate ก่อนเปิด WRITE
ต้องยืนยัน:
- packet framing
- command
- actuator/address
- payload format
- byte order
- checksum/CRC
- response/read-back

ห้ามถือว่า packet ที่ยังไม่ยืนยันเป็นคำสั่งเขียนจริง
