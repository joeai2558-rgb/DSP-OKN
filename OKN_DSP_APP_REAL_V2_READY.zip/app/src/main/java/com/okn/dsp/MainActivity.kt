package com.okn.dsp

import android.Manifest
import android.app.Activity
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*
import java.util.UUID

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private var scanner: BluetoothLeScanner? = null
    private var gatt: BluetoothGatt? = null
    private lateinit var log: TextView
    private lateinit var status: TextView
    private val permissionReq = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestBlePermissions()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 32, 24, 24)
        }
        status = TextView(this).apply { text = "สถานะ: พร้อมสแกน"; textSize = 18f }
        val scan = Button(this).apply { text = "สแกน DSP" }
        val stop = Button(this).apply { text = "หยุดสแกน" }
        val clear = Button(this).apply { text = "ล้าง Log" }
        log = TextView(this).apply {
            textSize = 12f
            setTextIsSelectable(true)
        }
        val scroll = ScrollView(this).apply { addView(log) }
        root.addView(status)
        root.addView(scan)
        root.addView(stop)
        root.addView(clear)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        scan.setOnClickListener { startScan() }
        stop.setOnClickListener { stopScan() }
        clear.setOnClickListener { log.text = "" }
    }

    private fun requestBlePermissions() {
        val needed = if (android.os.Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.BLUETOOTH)
        val missing = needed.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), permissionReq)
    }

    private fun startScan() {
        if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED &&
            android.os.Build.VERSION.SDK_INT >= 31) {
            requestBlePermissions(); return
        }
        val manager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        val adapter = manager.adapter
        if (adapter == null || !adapter.isEnabled) {
            status.text = "สถานะ: กรุณาเปิด Bluetooth"; return
        }
        scanner = adapter.bluetoothLeScanner
        status.text = "สถานะ: กำลังสแกน…"
        append("SCAN START")
        scanner?.startScan(scanCallback)
        handler.postDelayed({ stopScan() }, 12000)
    }

    private fun stopScan() {
        if (android.os.Build.VERSION.SDK_INT < 31 ||
            checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED) {
            scanner?.stopScan(scanCallback)
        }
        status.text = "สถานะ: หยุดสแกน"
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(type: Int, result: ScanResult) {
            val d = result.device
            val name = result.scanRecord?.deviceName ?: d.name ?: "(no name)"
            if (name == BleProfile.DEVICE_NAME || name.contains("DSP", true) || name.contains("Golo", true)) {
                append("พบ: $name  ${d.address}  RSSI=${result.rssi}")
                connect(d)
                stopScan()
            }
        }
        override fun onScanFailed(errorCode: Int) { append("SCAN ERROR=$errorCode") }
    }

    private fun connect(device: BluetoothDevice) {
        status.text = "สถานะ: กำลังเชื่อมต่อ ${device.address}"
        gatt?.close()
        gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                status.text = "สถานะ: เชื่อมต่อแล้ว — กำลังค้นหา Service"
                append("CONNECTED")
                g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                status.text = "สถานะ: ตัดการเชื่อมต่อ"
                append("DISCONNECTED status=$statusCode")
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
            append("SERVICES status=$statusCode")
            for (s in g.services) {
                append("SERVICE ${s.uuid}")
                for (c in s.characteristics) {
                    append("  CHAR ${c.uuid} props=${c.properties}")
                    if (BleProfile.UUIDS.contains(c.uuid)) enableNotify(g, c)
                }
            }
            status.text = "สถานะ: พร้อมรับข้อมูล — WRITE ถูกปิดไว้"
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            append("RX ${c.uuid}: ${c.value.toHex()}")
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicRead(g: BluetoothGatt, c: BluetoothGattCharacteristic, statusCode: Int) {
            append("READ ${c.uuid} status=$statusCode: ${c.value.toHex()}")
        }
    }

    private fun enableNotify(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
        if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED &&
            android.os.Build.VERSION.SDK_INT >= 31) return
        g.setCharacteristicNotification(c, true)
        val desc = c.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"))
        if (desc != null) {
            desc.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            g.writeDescriptor(desc)
        }
        append("NOTIFY enabled ${c.uuid}")
    }

    private fun append(s: String) {
        runOnUiThread { log.append(s + "\n") }
    }

    private fun ByteArray.toHex(): String = joinToString(" ") { "%02X".format(it) }

    override fun onDestroy() {
        gatt?.close()
        super.onDestroy()
    }
}