# OKN DSP App V2 — Real-device foundation

This project is deliberately split into two stages.

## What is real and implemented
- Android BLE permissions for modern Android.
- BLE scan.
- Automatic detection of `GoloPineDSPAudioTurning` / DSP-like names.
- GATT connection.
- Service/characteristic discovery.
- Notification subscription for the three UUID candidates from the research bundle.
- Raw RX hex logging.
- Safe default: no DSP write is performed.

## Why full DSP control is not honestly enabled yet
The supplied research bundle confirms command IDs and UUID candidates, but explicitly says the exact UFE packet framing, checksum/CRC, authentication payload, actuator IDs/paths, DSP memory addresses, and SigmaDSP coefficient byte order/scaling still need physical-device verification.

Therefore an app that claims "100% real control" from this data alone would risk sending invalid bytes to the DSP.

## Next unlock
Use this build with the physical DSP and capture the RX/TX traffic produced by the original working app while changing:
1. master volume
2. one EQ band
3. mute
4. crossover
5. preset save

Once those byte sequences are available, implement the verified codec and actuator map, then enable WRITE with range checks and a read-back verification path.